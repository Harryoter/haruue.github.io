##贴吧云签到安装和配置文件夹     
用于配置云签到以及升级
###文件说明
install.php  安装贴吧云签到      
toolkit.php  贴吧云签到工具箱    
check.php    环境检查文件
msg.php      前台错误消息提示文件
update.php   通用站点升级文件 
install.lock 安装锁定文件，如果本目录存在此文件将阻止运行安装程序保证站点安全 
template.table.sql   分表建立模板      
install.template.sql 云签到安装模板      
uninst.template.sql  云签到卸载模板      
update1.0to2.0.php   云签到V1.0到V2.0升级文件