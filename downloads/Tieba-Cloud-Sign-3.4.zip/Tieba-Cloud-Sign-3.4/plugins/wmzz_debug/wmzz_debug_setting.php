<?php
if (!defined('SYSTEM_ROOT')) { die('Insufficient Permissions'); } 
global $i;
echo '调试信息：<br/><br/><pre>';
print_r($i);
?></pre>